/*
  # Initial Schema for Synthetics Trading Bot SaaS

  1. New Tables
    - `profiles` — User profiles linked to auth.users, stores role (admin/user), encrypted API tokens
    - `licenses` — License keys for controlling user access, with expiration dates and status
    - `bot_configs` — Per-user bot configuration: selected indices, lot size, SL/TP, environment
    - `trades` — Historical trade log with entry/exit prices, result, confluence score
    - `bot_sessions` — Tracks active bot sessions (running/stopped/paused) for real-time monitoring
    - `chat_messages` — Stores chatbot conversation history per user

  2. Security
    - RLS enabled on ALL tables
    - Users can only read/write their own data
    - Admin role can access all data via policies
    - License validation is server-side only
*/

-- ============================================
-- PROFILES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  full_name text DEFAULT '',
  role text NOT NULL DEFAULT 'user' CHECK (role IN ('admin', 'user')),
  deriv_demo_token_encrypted text DEFAULT '',
  deriv_real_token_encrypted text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM profiles WHERE user_id = auth.uid() AND role = 'admin')
  );

-- ============================================
-- LICENSES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS licenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  license_key text UNIQUE NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'revoked', 'expired')),
  plan_type text NOT NULL DEFAULT 'trial' CHECK (plan_type IN ('trial', 'monthly', 'yearly', 'lifetime')),
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  activated_at timestamptz,
  created_by uuid REFERENCES auth.users(id)
);

ALTER TABLE licenses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own license"
  ON licenses FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admins can manage all licenses"
  ON licenses FOR ALL
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM profiles WHERE user_id = auth.uid() AND role = 'admin')
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM profiles WHERE user_id = auth.uid() AND role = 'admin')
  );

-- ============================================
-- BOT_CONFIGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS bot_configs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  environment text NOT NULL DEFAULT 'demo' CHECK (environment IN ('demo', 'real')),
  selected_indices text[] NOT NULL DEFAULT ARRAY['boom500'],
  lot_size numeric NOT NULL DEFAULT 0.2,
  daily_stop_loss numeric NOT NULL DEFAULT 50,
  daily_take_profit numeric NOT NULL DEFAULT 100,
  confluence_min_score integer NOT NULL DEFAULT 4 CHECK (confluence_min_score >= 1 AND confluence_min_score <= 5),
  enable_trailing_stop boolean DEFAULT true,
  enable_breakeven boolean DEFAULT true,
  trailing_stop_pips numeric DEFAULT 15,
  breakeven_at_pips numeric DEFAULT 10,
  max_consecutive_losses integer DEFAULT 2,
  pause_after_losses_minutes integer DEFAULT 30,
  enable_anti_fakeout boolean DEFAULT true,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE bot_configs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own config"
  ON bot_configs FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own config"
  ON bot_configs FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can insert own config"
  ON bot_configs FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- ============================================
-- TRADES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS trades (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  index_name text NOT NULL,
  trade_type text NOT NULL CHECK (trade_type IN ('buy', 'sell')),
  lot_size numeric NOT NULL,
  margin numeric DEFAULT 0,
  entry_price numeric NOT NULL,
  exit_price numeric,
  result numeric DEFAULT 0,
  confluence_score integer NOT NULL CHECK (confluence_score >= 1 AND confluence_score <= 5),
  confluence_details jsonb DEFAULT '{}',
  environment text NOT NULL DEFAULT 'demo' CHECK (environment IN ('demo', 'real')),
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'closed', 'cancelled')),
  opened_at timestamptz DEFAULT now(),
  closed_at timestamptz
);

ALTER TABLE trades ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own trades"
  ON trades FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own trades"
  ON trades FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own trades"
  ON trades FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all trades"
  ON trades FOR SELECT
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM profiles WHERE user_id = auth.uid() AND role = 'admin')
  );

-- ============================================
-- BOT_SESSIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS bot_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'off' CHECK (status IN ('running', 'off', 'paused')),
  environment text NOT NULL DEFAULT 'demo' CHECK (environment IN ('demo', 'real')),
  connected_at timestamptz,
  disconnected_at timestamptz,
  daily_pnl numeric DEFAULT 0,
  daily_trades integer DEFAULT 0,
  consecutive_losses integer DEFAULT 0,
  paused_until timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE bot_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own sessions"
  ON bot_sessions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own sessions"
  ON bot_sessions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own sessions"
  ON bot_sessions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all sessions"
  ON bot_sessions FOR SELECT
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM profiles WHERE user_id = auth.uid() AND role = 'admin')
  );

-- ============================================
-- CHAT_MESSAGES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('user', 'assistant')),
  content text NOT NULL,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own messages"
  ON chat_messages FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own messages"
  ON chat_messages FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- ============================================
-- INDEXES
-- ============================================
CREATE INDEX IF NOT EXISTS idx_trades_user_id ON trades(user_id);
CREATE INDEX IF NOT EXISTS idx_trades_opened_at ON trades(opened_at);
CREATE INDEX IF NOT EXISTS idx_bot_sessions_user_id ON bot_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_licenses_user_id ON licenses(user_id);
CREATE INDEX IF NOT EXISTS idx_licenses_license_key ON licenses(license_key);
