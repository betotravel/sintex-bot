import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Missing authorization" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 401 }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const token = authHeader.replace("Bearer ", "");
    const userRes = await fetch(`${supabaseUrl}/auth/v1/user`, {
      headers: { apikey: supabaseAnonKey, Authorization: `Bearer ${token}` },
    });
    const user = await userRes.json();

    if (!user?.id) {
      return new Response(
        JSON.stringify({ error: "Invalid token" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 401 }
      );
    }

    const url = new URL(req.url);
    const action = url.searchParams.get("action") || "summary";

    // Fetch user trades
    const tradesRes = await fetch(
      `${supabaseUrl}/rest/v1/trades?user_id=eq.${user.id}&status=eq.closed&order=opened_at.desc&select=*`,
      {
        headers: { apikey: supabaseKey, Authorization: `Bearer ${supabaseKey}` },
      }
    );
    const trades = await tradesRes.json();

    if (action === "summary") {
      const wins = trades.filter((t: any) => t.result > 0);
      const losses = trades.filter((t: any) => t.result < 0);
      const totalPnl = trades.reduce((s: number, t: any) => s + t.result, 0);
      const winRate = trades.length > 0 ? ((wins.length / trades.length) * 100).toFixed(1) : "0";

      // Per-index breakdown
      const byIndex: Record<string, any> = {};
      for (const t of trades) {
        if (!byIndex[t.index_name]) {
          byIndex[t.index_name] = { trades: 0, wins: 0, losses: 0, pnl: 0 };
        }
        byIndex[t.index_name].trades++;
        if (t.result > 0) byIndex[t.index_name].wins++;
        else byIndex[t.index_name].losses++;
        byIndex[t.index_name].pnl += t.result;
      }

      // Confluence breakdown
      const byScore: Record<number, any> = {};
      for (const t of trades) {
        if (!byScore[t.confluence_score]) {
          byScore[t.confluence_score] = { trades: 0, wins: 0, pnl: 0 };
        }
        byScore[t.confluence_score].trades++;
        if (t.result > 0) byScore[t.confluence_score].wins++;
        byScore[t.confluence_score].pnl += t.result;
      }

      return new Response(
        JSON.stringify({
          total_trades: trades.length,
          wins: wins.length,
          losses: losses.length,
          win_rate: parseFloat(winRate),
          total_pnl: Math.round(totalPnl * 100) / 100,
          by_index: byIndex,
          by_score: byScore,
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (action === "ai-insights") {
      // Generate AI-like insights from trade data
      const insights: string[] = [];

      // Time-based analysis
      const hourBuckets: Record<number, { wins: number; total: number }> = {};
      for (const t of trades) {
        const hour = new Date(t.opened_at).getHours();
        if (!hourBuckets[hour]) hourBuckets[hour] = { wins: 0, total: 0 };
        hourBuckets[hour].total++;
        if (t.result > 0) hourBuckets[hour].wins++;
      }

      // Find worst performing hours
      const worstHours = Object.entries(hourBuckets)
        .map(([h, d]) => ({ hour: parseInt(h), rate: d.wins / d.total, trades: d.total }))
        .filter((d) => d.trades >= 3 && d.rate < 0.4)
        .sort((a, b) => a.rate - b.rate);

      for (const wh of worstHours.slice(0, 2)) {
        insights.push(
          `Low effectiveness at ${wh.hour}:00-${wh.hour + 1}:00 UTC (${(wh.rate * 100).toFixed(0)}% win rate across ${wh.trades} trades). Consider pausing trading during this window.`
        );
      }

      // Best performing index
      const indexPerf: Record<string, { pnl: number; rate: number; trades: number }> = {};
      for (const t of trades) {
        if (!indexPerf[t.index_name]) indexPerf[t.index_name] = { pnl: 0, rate: 0, trades: 0 };
        indexPerf[t.index_name].pnl += t.result;
        indexPerf[t.index_name].trades++;
        if (t.result > 0) indexPerf[t.index_name].rate++;
      }
      for (const idx of Object.keys(indexPerf)) {
        indexPerf[idx].rate = indexPerf[idx].rate / indexPerf[idx].trades;
      }

      const bestIndex = Object.entries(indexPerf).sort(([, a], [, b]) => b.rate - a.rate)[0];
      if (bestIndex && bestIndex[1].rate > 0.6) {
        insights.push(
          `Your effectiveness on ${bestIndex[0]} is ${(bestIndex[1].rate * 100).toFixed(0)}% — your strongest configuration. Consider focusing here.`
        );
      }

      // Fibonacci effectiveness
      const fibTrades = trades.filter(
        (t: any) => t.confluence_details?.fibonacci?.score === 1
      );
      if (fibTrades.length >= 3) {
        const fibWinRate = fibTrades.filter((t: any) => t.result > 0).length / fibTrades.length;
        insights.push(
          `Fibonacci-confirmed trades: ${(fibWinRate * 100).toFixed(0)}% win rate (${fibTrades.length} trades). ${fibWinRate > 0.6 ? "This is a strong filter for your strategy." : "Consider reviewing Fibonacci zone settings."}`
        );
      }

      if (insights.length === 0) {
        insights.push("Not enough trade data for meaningful insights. Continue trading to build your performance profile.");
      }

      return new Response(
        JSON.stringify({ insights }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ error: "Unknown action" }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 400 }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: "Analytics request failed" }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 500 }
    );
  }
});
