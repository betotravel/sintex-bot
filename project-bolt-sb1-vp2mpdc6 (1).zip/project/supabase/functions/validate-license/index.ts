import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { license_key } = await req.json();

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const response = await fetch(
      `${supabaseUrl}/rest/v1/licenses?license_key=eq.${license_key}&select=*`,
      {
        headers: {
          apikey: supabaseKey,
          Authorization: `Bearer ${supabaseKey}`,
          "Content-Type": "application/json",
        },
      }
    );

    const licenses = await response.json();

    if (!licenses || licenses.length === 0) {
      return new Response(
        JSON.stringify({ valid: false, reason: "License key not found" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 404 }
      );
    }

    const license = licenses[0];

    if (license.status === "revoked") {
      return new Response(
        JSON.stringify({ valid: false, reason: "License has been revoked" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 403 }
      );
    }

    if (license.status === "suspended") {
      return new Response(
        JSON.stringify({ valid: false, reason: "License is suspended" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 403 }
      );
    }

    const now = new Date().toISOString();
    if (new Date(license.expires_at).toISOString() < now) {
      // Mark as expired
      await fetch(
        `${supabaseUrl}/rest/v1/licenses?id=eq.${license.id}`,
        {
          method: "PATCH",
          headers: {
            apikey: supabaseKey,
            Authorization: `Bearer ${supabaseKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ status: "expired" }),
        }
      );
      return new Response(
        JSON.stringify({ valid: false, reason: "License has expired" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 403 }
      );
    }

    return new Response(
      JSON.stringify({
        valid: true,
        license: {
          id: license.id,
          plan_type: license.plan_type,
          expires_at: license.expires_at,
          status: license.status,
        },
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ valid: false, reason: "Validation failed" }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 500 }
    );
  }
});
