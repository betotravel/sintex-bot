import { useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import type { Trade } from '../../lib/types';
import { formatDate } from '../../lib/utils';

interface Props {
  trades: Trade[];
}

export function BalanceChart({ trades }: Props) {
  const data = useMemo(() => {
    let balance = 10000; // Starting demo balance
    const closedTrades = trades
      .filter((t) => t.status === 'closed')
      .sort((a, b) => new Date(a.opened_at).getTime() - new Date(b.opened_at).getTime());

    const points = [{ date: 'Start', balance, pnl: 0 }];
    for (const trade of closedTrades) {
      balance += trade.result;
      points.push({
        date: formatDate(trade.opened_at),
        balance: Math.round(balance * 100) / 100,
        pnl: trade.result,
      });
    }
    return points;
  }, [trades]);

  const isPositive = data.length > 1 && data[data.length - 1].balance >= data[0].balance;
  const chartColor = isPositive ? '#34d399' : '#f87171';

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-white">Balance History</h3>
        <span className={`text-sm font-bold ${isPositive ? 'text-emerald-400' : 'text-red-400'}`}>
          {data.length > 1
            ? `${isPositive ? '+' : ''}$${(data[data.length - 1].balance - data[0].balance).toFixed(2)}`
            : '$0.00'}
        </span>
      </div>
      <div className="h-48 sm:h-56">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
            <defs>
              <linearGradient id="balanceGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={chartColor} stopOpacity={0.3} />
                <stop offset="100%" stopColor={chartColor} stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
            <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
            <YAxis
              tick={{ fontSize: 10, fill: '#64748b' }}
              axisLine={false}
              tickLine={false}
              domain={['dataMin - 100', 'dataMax + 100']}
              tickFormatter={(v) => `$${v}`}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: '#0f172a',
                border: '1px solid #1e293b',
                borderRadius: '12px',
                fontSize: '12px',
              }}
              labelStyle={{ color: '#94a3b8' }}
              itemStyle={{ color: chartColor }}
              formatter={(value: number) => [`$${value.toFixed(2)}`, 'Balance']}
            />
            <Area
              type="monotone"
              dataKey="balance"
              stroke={chartColor}
              strokeWidth={2}
              fill="url(#balanceGradient)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
