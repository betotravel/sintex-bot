import type { ConfluenceResult } from '../../lib/types';
import { CheckCircle, XCircle } from 'lucide-react';

interface Props {
  result: ConfluenceResult;
}

const filters = [
  { key: 'price_action', label: 'Price Action', desc: 'Trend structure (M15/H1)' },
  { key: 'support_resistance', label: 'Support & Resistance', desc: 'Key levels & Order Blocks' },
  { key: 'fibonacci', label: 'Fibonacci', desc: 'Golden Zone (61.8% / 78.6%)' },
  { key: 'spike_reaction', label: 'Spike Reaction', desc: 'Post-spike pullback (3-5 candles)' },
  { key: 'indicators', label: 'Indicators', desc: 'EMA crossover & RSI extremes' },
] as const;

export function ConfluencePanel({ result }: Props) {
  const scoreColor =
    result.totalScore >= 4
      ? 'text-emerald-400'
      : result.totalScore >= 2
      ? 'text-amber-400'
      : 'text-red-400';

  const scoreBg =
    result.totalScore >= 4
      ? 'bg-emerald-500/10 border-emerald-500/20'
      : result.totalScore >= 2
      ? 'bg-amber-500/10 border-amber-500/20'
      : 'bg-red-500/10 border-red-500/20';

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-white">Confluence Score</h3>
        <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-xl border ${scoreBg}`}>
          <span className={`text-lg font-bold ${scoreColor}`}>{result.totalScore}</span>
          <span className="text-xs text-slate-500">/5</span>
        </div>
      </div>

      <div className="space-y-2">
        {filters.map((filter) => {
          const detail = result.details[filter.key];
          const passed = detail.score === 1;
          return (
            <div
              key={filter.key}
              className={`flex items-center gap-3 p-3 rounded-xl transition-all ${
                passed ? 'bg-emerald-500/5 border border-emerald-500/10' : 'bg-slate-800/30 border border-transparent'
              }`}
            >
              {passed ? (
                <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0" />
              ) : (
                <XCircle className="w-5 h-5 text-slate-600 flex-shrink-0" />
              )}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className={`text-sm font-medium ${passed ? 'text-white' : 'text-slate-500'}`}>
                    {filter.label}
                  </p>
                  <span className={`text-xs font-bold ${passed ? 'text-emerald-400' : 'text-slate-600'}`}>
                    {detail.score}pt
                  </span>
                </div>
                <p className={`text-xs mt-0.5 ${passed ? 'text-emerald-400/70' : 'text-slate-600'}`}>
                  {detail.reason}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {result.signal && result.totalScore >= 4 && (
        <div className="mt-4 p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-center gap-2">
          <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
          <p className="text-sm font-bold text-emerald-400">
            SIGNAL: {result.signal.toUpperCase()}
          </p>
        </div>
      )}
    </div>
  );
}
