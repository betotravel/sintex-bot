import { useState, useEffect } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { supabase } from '../../lib/supabase';
import { simpleEncrypt, simpleDecrypt } from '../../lib/utils';
import { SYNTHETIC_INDICES } from '../../lib/types';
import type { BotConfig, Environment, SyntheticIndexId } from '../../lib/types';
import {
  Settings as SettingsIcon,
  Key,
  Shield,
  Save,
  Eye,
  EyeOff,
  Check,
} from 'lucide-react';

export function Settings() {
  const { user, profile, fetchProfile } = useAuth();
  const [config, setConfig] = useState<BotConfig | null>(null);
  const [demoToken, setDemoToken] = useState('');
  const [realToken, setRealToken] = useState('');
  const [showDemo, setShowDemo] = useState(false);
  const [showReal, setShowReal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!user || !profile) return;
    // Load config
    supabase
      .from('bot_configs')
      .select('*')
      .eq('user_id', user.id)
      .maybeSingle()
      .then(({ data }) => {
        if (data) setConfig(data);
        else {
          // Create default config
          supabase
            .from('bot_configs')
            .insert({ user_id: user.id })
            .select()
            .maybeSingle()
            .then(({ data: newData }) => setConfig(newData ?? null));
        }
      });

    // Load tokens
    setDemoToken(simpleDecrypt(profile.deriv_demo_token_encrypted));
    setRealToken(simpleDecrypt(profile.deriv_real_token_encrypted));
  }, [user, profile]);

  async function handleSave() {
    if (!user || !config) return;
    setSaving(true);
    setSaved(false);

    try {
      // Save tokens to profile
      await supabase
        .from('profiles')
        .update({
          deriv_demo_token_encrypted: simpleEncrypt(demoToken),
          deriv_real_token_encrypted: simpleEncrypt(realToken),
        })
        .eq('user_id', user.id);

      // Save config
      await supabase
        .from('bot_configs')
        .update(config)
        .eq('user_id', user.id);

      await fetchProfile(user.id);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err) {
      console.error('Save failed:', err);
    } finally {
      setSaving(false);
    }
  }

  function updateConfig<K extends keyof BotConfig>(key: K, value: BotConfig[K]) {
    if (!config) return;
    setConfig({ ...config, [key]: value });
  }

  function toggleIndex(indexId: SyntheticIndexId) {
    if (!config) return;
    const current = config.selected_indices;
    if (current.includes(indexId)) {
      updateConfig('selected_indices', current.filter((i) => i !== indexId) as SyntheticIndexId[]);
    } else {
      updateConfig('selected_indices', [...current, indexId] as SyntheticIndexId[]);
    }
  }

  if (!config) return <div className="text-slate-500">Loading...</div>;

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
          <p className="text-slate-400 text-sm mt-1">Configure your trading bot and API access</p>
        </div>
        <button
          onClick={handleSave}
          disabled={saving}
          className="flex items-center gap-2 px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 disabled:bg-slate-700 text-white text-sm font-medium rounded-xl transition-all shadow-lg shadow-emerald-500/25 active:scale-[0.98]"
        >
          {saving ? (
            <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : saved ? (
            <Check className="w-4 h-4" />
          ) : (
            <Save className="w-4 h-4" />
          )}
          {saved ? 'Saved' : 'Save'}
        </button>
      </div>

      {/* API Tokens */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <Key className="w-5 h-5 text-emerald-400" />
          <h3 className="text-sm font-semibold text-white">Deriv API Tokens</h3>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Demo Account Token</label>
            <div className="relative">
              <input
                type={showDemo ? 'text' : 'password'}
                value={demoToken}
                onChange={(e) => setDemoToken(e.target.value)}
                placeholder="Enter your Deriv demo token"
                className="w-full px-4 py-2.5 pr-12 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all font-mono"
              />
              <button
                type="button"
                onClick={() => setShowDemo(!showDemo)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                {showDemo ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Real Account Token</label>
            <div className="relative">
              <input
                type={showReal ? 'text' : 'password'}
                value={realToken}
                onChange={(e) => setRealToken(e.target.value)}
                placeholder="Enter your Deriv real token"
                className="w-full px-4 py-2.5 pr-12 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all font-mono"
              />
              <button
                type="button"
                onClick={() => setShowReal(!showReal)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                {showReal ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="flex items-start gap-2 p-3 bg-blue-500/5 border border-blue-500/10 rounded-xl">
            <Shield className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-blue-300/70">
              Tokens are encrypted locally before storage. Never share your tokens with anyone.
            </p>
          </div>
        </div>
      </div>

      {/* Index Selection */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
        <h3 className="text-sm font-semibold text-white mb-4">Synthetic Indices</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {SYNTHETIC_INDICES.map((idx) => {
            const active = config.selected_indices.includes(idx.id);
            return (
              <button
                key={idx.id}
                onClick={() => toggleIndex(idx.id)}
                className={`p-3 rounded-xl text-sm font-medium transition-all border-2 ${
                  active
                    ? 'border-emerald-500/50 bg-emerald-500/10 text-emerald-400'
                    : 'border-slate-700 bg-slate-800/50 text-slate-400 hover:border-slate-600'
                }`}
              >
                {idx.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Trading Parameters */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
        <h3 className="text-sm font-semibold text-white">Trading Parameters</h3>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Lot Size</label>
            <input
              type="number"
              value={config.lot_size}
              onChange={(e) => updateConfig('lot_size', parseFloat(e.target.value) || 0.2)}
              step={0.1}
              min={0.1}
              max={10}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Min Confluence Score</label>
            <select
              value={config.confluence_min_score}
              onChange={(e) => updateConfig('confluence_min_score', parseInt(e.target.value))}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
            >
              {[3, 4, 5].map((s) => (
                <option key={s} value={s}>{s} / 5</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Daily Stop Loss ($)</label>
            <input
              type="number"
              value={config.daily_stop_loss}
              onChange={(e) => updateConfig('daily_stop_loss', parseFloat(e.target.value) || 50)}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Daily Take Profit ($)</label>
            <input
              type="number"
              value={config.daily_take_profit}
              onChange={(e) => updateConfig('daily_take_profit', parseFloat(e.target.value) || 100)}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
            />
          </div>
        </div>
      </div>

      {/* Risk Management */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
        <h3 className="text-sm font-semibold text-white">Risk Management</h3>

        <div className="space-y-3">
          <ToggleSetting
            label="Trailing Stop"
            description="Automatically trail price with configurable pips"
            checked={config.enable_trailing_stop}
            onChange={(v) => updateConfig('enable_trailing_stop', v)}
          />
          <ToggleSetting
            label="Breakeven"
            description="Move SL to entry when profit reaches threshold"
            checked={config.enable_breakeven}
            onChange={(v) => updateConfig('enable_breakeven', v)}
          />
          <ToggleSetting
            label="Anti-Fakeout (Re-entry)"
            description="Re-enter if price reacts at key structural zone"
            checked={config.enable_anti_fakeout}
            onChange={(v) => updateConfig('enable_anti_fakeout', v)}
          />
        </div>

        <div className="grid grid-cols-2 gap-4 pt-2">
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Trailing Stop (pips)</label>
            <input
              type="number"
              value={config.trailing_stop_pips}
              onChange={(e) => updateConfig('trailing_stop_pips', parseFloat(e.target.value) || 15)}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Breakeven at (pips)</label>
            <input
              type="number"
              value={config.breakeven_at_pips}
              onChange={(e) => updateConfig('breakeven_at_pips', parseFloat(e.target.value) || 10)}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Max Consecutive Losses</label>
            <input
              type="number"
              value={config.max_consecutive_losses}
              onChange={(e) => updateConfig('max_consecutive_losses', parseInt(e.target.value) || 2)}
              min={1}
              max={10}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Pause Duration (min)</label>
            <input
              type="number"
              value={config.pause_after_losses_minutes}
              onChange={(e) => updateConfig('pause_after_losses_minutes', parseInt(e.target.value) || 30)}
              min={5}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function ToggleSetting({
  label,
  description,
  checked,
  onChange,
}: {
  label: string;
  description: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between p-3 bg-slate-800/30 rounded-xl">
      <div>
        <p className="text-sm font-medium text-white">{label}</p>
        <p className="text-xs text-slate-500">{description}</p>
      </div>
      <button
        onClick={() => onChange(!checked)}
        className={`relative w-12 h-7 rounded-full transition-all ${
          checked ? 'bg-emerald-500' : 'bg-slate-700'
        }`}
      >
        <div
          className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow-md transition-all ${
            checked ? 'left-6' : 'left-1'
          }`}
        />
      </button>
    </div>
  );
}
