import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { useBotSession } from '../../hooks/useBotSession';
import { supabase } from '../../lib/supabase';
import { derivApi } from '../../lib/derivApi';
import { calculateConfluence } from '../../lib/indicators';
import { RiskManager } from '../../lib/riskManager';
import { simpleEncrypt, simpleDecrypt, formatCurrency } from '../../lib/utils';
import { SYNTHETIC_INDICES } from '../../lib/types';
import type { BotConfig, Trade, Environment, BotStatus, ConfluenceResult } from '../../lib/types';
import {
  Play,
  Square,
  AlertTriangle,
  Wifi,
  WifiOff,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Activity,
  Target,
  BarChart3,
  ChevronDown,
  Zap,
} from 'lucide-react';
import { BalanceChart } from './BalanceChart';
import { ConfluencePanel } from './ConfluencePanel';

export function Dashboard() {
  const { user, profile } = useAuth();
  const [config, setConfig] = useState<BotConfig | null>(null);
  const [environment, setEnvironment] = useState<Environment>('demo');
  const [trades, setTrades] = useState<Trade[]>([]);
  const [confluenceResult, setConfluenceResult] = useState<ConfluenceResult | null>(null);
  const [balance, setBalance] = useState<number | null>(null);
  const [connected, setConnected] = useState(false);
  const [scanning, setScanning] = useState(false);
  const riskManagerRef = useState(new RiskManager(config ?? ({} as BotConfig)))[0];

  const {
    status,
    dailyPnl,
    dailyTrades,
    consecutiveLosses,
    pausedUntil,
    startBot,
    stopBot,
    panicStop,
    resumeFromPause,
  } = useBotSession(user?.id, environment);

  // Load config
  useEffect(() => {
    if (!user) return;
    supabase
      .from('bot_configs')
      .select('*')
      .eq('user_id', user.id)
      .maybeSingle()
      .then(({ data }) => {
        if (data) {
          setConfig(data);
          setEnvironment(data.environment);
        }
      });
  }, [user]);

  // Load recent trades
  useEffect(() => {
    if (!user) return;
    const fetchTrades = async () => {
      const { data } = await supabase
        .from('trades')
        .select('*')
        .eq('user_id', user.id)
        .order('opened_at', { ascending: false })
        .limit(20);
      setTrades(data ?? []);
    };
    fetchTrades();
    const interval = setInterval(fetchTrades, 10000);
    return () => clearInterval(interval);
  }, [user]);

  // Connect to Deriv and start scanning
  const connectAndScan = useCallback(async () => {
    if (!profile || !config) return;

    const tokenField =
      environment === 'demo'
        ? profile.deriv_demo_token_encrypted
        : profile.deriv_real_token_encrypted;
    const token = simpleDecrypt(tokenField);
    if (!token) {
      console.error('No API token configured');
      return;
    }

    try {
      await derivApi.connect(token);
      setConnected(true);

      derivApi.onConnect(() => setConnected(true));
      derivApi.onDisconnect(() => setConnected(false));

      // Subscribe to balance
      derivApi.getBalance();
      derivApi.on('balance', (data) => {
        if (data.balance) setBalance(parseFloat(String(data.balance.balance)));
      });

      // Start scanning selected indices
      for (const indexId of config.selected_indices) {
        const indexInfo = SYNTHETIC_INDICES.find((i) => i.id === indexId);
        if (!indexInfo) continue;
        derivApi.subscribeCandles(indexInfo.symbol);
      }

      derivApi.on('ohlc', (data) => {
        if (data.ohlc) {
          // Process candle data for confluence analysis
          setScanning(true);
          const candles = data.ohlc;
          const result = calculateConfluence(candles, config.selected_indices[0]);
          setConfluenceResult(result);

          if (result.totalScore >= config.confluence_min_score && result.signal) {
            // Execute trade
            executeTrade(result);
          }
          setScanning(false);
        }
      });
    } catch (err) {
      console.error('Connection failed:', err);
      setConnected(false);
    }
  }, [profile, config, environment]);

  const executeTrade = useCallback(
    async (result: ConfluenceResult) => {
      if (!user || !config) return;

      const indexId = config.selected_indices[0];
      const indexInfo = SYNTHETIC_INDICES.find((i) => i.id === indexId);
      if (!indexInfo) return;

      const price = result.signal === 'buy' ? 1 : 0;
      derivApi.buy(
        result.signal === 'buy' ? 'BUY' : 'SELL',
        indexInfo.symbol,
        config.lot_size
      );

      // Record trade
      await supabase.from('trades').insert({
        user_id: user.id,
        index_name: indexId,
        trade_type: result.signal,
        lot_size: config.lot_size,
        entry_price: price,
        confluence_score: result.totalScore,
        confluence_details: result.details,
        environment,
        status: 'open',
      });
    },
    [user, config, environment]
  );

  const handleStart = async () => {
    await startBot();
    await connectAndScan();
  };

  const handleStop = async () => {
    derivApi.disconnect();
    setConnected(false);
    await stopBot();
  };

  const handlePanic = async () => {
    derivApi.disconnect();
    setConnected(false);
    await panicStop();
  };

  const statusConfig: Record<BotStatus, { label: string; color: string; bg: string }> = {
    running: { label: 'RUNNING', color: 'text-emerald-400', bg: 'bg-emerald-500/10 border-emerald-500/20' },
    off: { label: 'OFFLINE', color: 'text-slate-400', bg: 'bg-slate-800/50 border-slate-700' },
    paused: { label: 'PAUSED', color: 'text-amber-400', bg: 'bg-amber-500/10 border-amber-500/20' },
  };

  const currentStatus = statusConfig[status];
  const todayTrades = trades.filter((t) => {
    const d = new Date(t.opened_at);
    const now = new Date();
    return d.toDateString() === now.toDateString();
  });

  const todayPnl = todayTrades
    .filter((t) => t.status === 'closed')
    .reduce((sum, t) => sum + t.result, 0);

  const winRate =
    todayTrades.filter((t) => t.status === 'closed').length > 0
      ? (
          (todayTrades.filter((t) => t.result > 0).length /
            todayTrades.filter((t) => t.status === 'closed').length) *
          100
        ).toFixed(1)
      : '0.0';

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Trading Dashboard</h1>
          <p className="text-slate-400 text-sm mt-1">Monitor and control your automated trading bot</p>
        </div>
        <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl border ${currentStatus.bg}`}>
          <div className={`w-2 h-2 rounded-full ${status === 'running' ? 'bg-emerald-400 animate-pulse' : status === 'paused' ? 'bg-amber-400' : 'bg-slate-500'}`} />
          <span className={`text-sm font-semibold ${currentStatus.color}`}>{currentStatus.label}</span>
          {connected && <Wifi className="w-4 h-4 text-emerald-400" />}
          {!connected && <WifiOff className="w-4 h-4 text-slate-500" />}
        </div>
      </div>

      {/* Control Buttons */}
      <div className="grid grid-cols-3 gap-3 sm:gap-4">
        <button
          onClick={handleStart}
          disabled={status === 'running'}
          className="relative group flex flex-col items-center justify-center gap-2 py-5 sm:py-6 bg-emerald-500/10 border-2 border-emerald-500/30 rounded-2xl hover:bg-emerald-500/20 hover:border-emerald-500/50 transition-all disabled:opacity-40 disabled:cursor-not-allowed active:scale-[0.97]"
        >
          <Play className="w-7 h-7 text-emerald-400 group-hover:scale-110 transition-transform" />
          <span className="text-sm font-bold text-emerald-400 tracking-wide">ENCENDER</span>
        </button>

        <button
          onClick={handleStop}
          disabled={status === 'off'}
          className="relative group flex flex-col items-center justify-center gap-2 py-5 sm:py-6 bg-red-500/10 border-2 border-red-500/30 rounded-2xl hover:bg-red-500/20 hover:border-red-500/50 transition-all disabled:opacity-40 disabled:cursor-not-allowed active:scale-[0.97]"
        >
          <Square className="w-7 h-7 text-red-400 group-hover:scale-110 transition-transform" />
          <span className="text-sm font-bold text-red-400 tracking-wide">APAGAR</span>
        </button>

        <button
          onClick={handlePanic}
          disabled={status === 'off'}
          className="relative group flex flex-col items-center justify-center gap-2 py-5 sm:py-6 bg-amber-500/10 border-2 border-amber-500/30 rounded-2xl hover:bg-amber-500/20 hover:border-amber-500/50 transition-all disabled:opacity-40 disabled:cursor-not-allowed active:scale-[0.97]"
        >
          <AlertTriangle className="w-7 h-7 text-amber-400 group-hover:scale-110 transition-transform" />
          <span className="text-sm font-bold text-amber-400 tracking-wide">PARAR</span>
        </button>
      </div>

      {/* Environment Switch */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${environment === 'demo' ? 'bg-blue-500/10' : 'bg-orange-500/10'}`}>
              {environment === 'demo' ? (
                <TestTube2 className="w-5 h-5 text-blue-400" />
              ) : (
                <Zap className="w-5 h-5 text-orange-400" />
              )}
            </div>
            <div>
              <p className="text-sm font-semibold text-white">Trading Environment</p>
              <p className="text-xs text-slate-500">
                {environment === 'demo' ? 'Virtual funds - same execution speed' : 'Real money - live trading'}
              </p>
            </div>
          </div>
          <div className="flex bg-slate-800 rounded-xl p-1">
            <button
              onClick={() => setEnvironment('demo')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition-all ${
                environment === 'demo'
                  ? 'bg-blue-500 text-white shadow-lg'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              DEMO
            </button>
            <button
              onClick={() => setEnvironment('real')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition-all ${
                environment === 'real'
                  ? 'bg-orange-500 text-white shadow-lg'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              REAL
            </button>
          </div>
        </div>
      </div>

      {/* Pause Notice */}
      {status === 'paused' && pausedUntil && (
        <div className="bg-amber-500/10 border border-amber-500/20 rounded-2xl p-4 flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0" />
          <div className="flex-1">
            <p className="text-sm font-medium text-amber-300">
              Bot paused due to consecutive losses
            </p>
            <p className="text-xs text-amber-400/60">
              Resumes at {new Date(pausedUntil).toLocaleTimeString()}
            </p>
          </div>
          <button
            onClick={resumeFromPause}
            className="px-3 py-1.5 bg-amber-500/20 text-amber-400 text-xs font-bold rounded-lg hover:bg-amber-500/30 transition-all"
          >
            Resume
          </button>
        </div>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard
          icon={DollarSign}
          label="Daily P/L"
          value={formatCurrency(todayPnl)}
          positive={todayPnl >= 0}
        />
        <StatCard
          icon={Activity}
          label="Trades Today"
          value={String(todayTrades.length)}
        />
        <StatCard
          icon={Target}
          label="Win Rate"
          value={`${winRate}%`}
          positive={parseFloat(winRate) >= 50}
        />
        <StatCard
          icon={BarChart3}
          label="Balance"
          value={balance ? formatCurrency(balance) : '---'}
        />
      </div>

      {/* Chart */}
      <BalanceChart trades={trades} />

      {/* Confluence Panel */}
      {confluenceResult && <ConfluencePanel result={confluenceResult} />}

      {/* Scanning Indicator */}
      {status === 'running' && scanning && (
        <div className="flex items-center gap-2 text-sm text-slate-400">
          <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
          Scanning market for confluences...
        </div>
      )}

      {/* Recent Trades Mini Table */}
      {trades.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
          <div className="p-4 border-b border-slate-800">
            <h3 className="text-sm font-semibold text-white">Recent Trades</h3>
          </div>
          <div className="divide-y divide-slate-800/50">
            {trades.slice(0, 5).map((trade) => (
              <div key={trade.id} className="px-4 py-3 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                      trade.trade_type === 'buy'
                        ? 'bg-emerald-500/10'
                        : 'bg-red-500/10'
                    }`}
                  >
                    {trade.trade_type === 'buy' ? (
                      <TrendingUp className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-400" />
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">{trade.index_name}</p>
                    <p className="text-xs text-slate-500">
                      Score: {trade.confluence_score}/5
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p
                    className={`text-sm font-semibold ${
                      trade.result > 0 ? 'text-emerald-400' : trade.result < 0 ? 'text-red-400' : 'text-slate-400'
                    }`}
                  >
                    {trade.status === 'open' ? 'Open' : formatCurrency(trade.result)}
                  </p>
                  <p className="text-xs text-slate-500">{trade.lot_size} lots</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  positive,
}: {
  icon: any;
  label: string;
  value: string;
  positive?: boolean;
}) {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
      <div className="flex items-center gap-2 mb-2">
        <Icon className="w-4 h-4 text-slate-500" />
        <span className="text-xs text-slate-500 font-medium">{label}</span>
      </div>
      <p
        className={`text-lg font-bold tracking-tight ${
          positive === true
            ? 'text-emerald-400'
            : positive === false
            ? 'text-red-400'
            : 'text-white'
        }`}
      >
        {value}
      </p>
    </div>
  );
}

function TestTube2(props: any) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M9 3h6" />
      <path d="M10 9V3h4v6" />
      <path d="M10 9l-4 9a3 3 0 0 0 2.6 4.5h6.8a3 3 0 0 0 2.6-4.5l-4-9" />
    </svg>
  );
}
