import { useState, useEffect } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { supabase } from '../../lib/supabase';
import { generateLicenseKey, formatDateShort } from '../../lib/utils';
import type { Profile, License } from '../../lib/types';
import {
  Shield,
  Key,
  Users,
  Activity,
  Plus,
  Ban,
  CheckCircle,
  Clock,
  XCircle,
  Copy,
} from 'lucide-react';

export function AdminPanel() {
  const { isAdmin } = useAuth();
  const [users, setUsers] = useState<Profile[]>([]);
  const [licenses, setLicenses] = useState<License[]>([]);
  const [activeSessions, setActiveSessions] = useState(0);
  const [newPlanType, setNewPlanType] = useState<'trial' | 'monthly' | 'yearly' | 'lifetime'>('trial');
  const [newExpiryDays, setNewExpiryDays] = useState(30);
  const [generating, setGenerating] = useState(false);
  const [newKey, setNewKey] = useState('');
  const [tab, setTab] = useState<'licenses' | 'users' | 'sessions'>('licenses');

  useEffect(() => {
    if (!isAdmin) return;
    loadData();
    const interval = setInterval(loadData, 15000);
    return () => clearInterval(interval);
  }, [isAdmin]);

  async function loadData() {
    const [usersRes, licensesRes, sessionsRes] = await Promise.all([
      supabase.from('profiles').select('*').order('created_at', { ascending: false }),
      supabase.from('licenses').select('*').order('created_at', { ascending: false }),
      supabase.from('bot_sessions').select('*').eq('status', 'running'),
    ]);
    setUsers(usersRes.data ?? []);
    setLicenses(licensesRes.data ?? []);
    setActiveSessions(sessionsRes.data?.length ?? 0);
  }

  async function generateLicense() {
    setGenerating(true);
    try {
      const key = generateLicenseKey();
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + newExpiryDays);

      const { data } = await supabase
        .from('licenses')
        .insert({
          license_key: key,
          plan_type: newPlanType,
          expires_at: expiresAt.toISOString(),
          status: 'active',
        })
        .select()
        .maybeSingle();

      if (data) {
        setNewKey(key);
        setLicenses([data, ...licenses]);
      }
    } catch (err) {
      console.error('Failed to generate license:', err);
    } finally {
      setGenerating(false);
    }
  }

  async function toggleLicense(license: License, newStatus: 'active' | 'suspended' | 'revoked') {
    await supabase
      .from('licenses')
      .update({ status: newStatus })
      .eq('id', license.id);
    loadData();
  }

  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="text-center">
          <Shield className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <p className="text-slate-400">Admin access required</p>
        </div>
      </div>
    );
  }

  const statusIcon = (status: string) => {
    switch (status) {
      case 'active':
        return <CheckCircle className="w-4 h-4 text-emerald-400" />;
      case 'suspended':
        return <Clock className="w-4 h-4 text-amber-400" />;
      case 'revoked':
        return <XCircle className="w-4 h-4 text-red-400" />;
      case 'expired':
        return <XCircle className="w-4 h-4 text-slate-500" />;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Admin Panel</h1>
        <p className="text-slate-400 text-sm mt-1">Manage licenses, users, and monitor activity</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-center">
          <Users className="w-5 h-5 text-blue-400 mx-auto mb-2" />
          <p className="text-2xl font-bold text-white">{users.length}</p>
          <p className="text-xs text-slate-500">Total Users</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-center">
          <Key className="w-5 h-5 text-emerald-400 mx-auto mb-2" />
          <p className="text-2xl font-bold text-white">
            {licenses.filter((l) => l.status === 'active').length}
          </p>
          <p className="text-xs text-slate-500">Active Licenses</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-center">
          <Activity className="w-5 h-5 text-amber-400 mx-auto mb-2" />
          <p className="text-2xl font-bold text-white">{activeSessions}</p>
          <p className="text-xs text-slate-500">Online Now</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex bg-slate-800 rounded-xl p-1 gap-1">
        {(['licenses', 'users', 'sessions'] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all capitalize ${
              tab === t ? 'bg-slate-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Licenses Tab */}
      {tab === 'licenses' && (
        <div className="space-y-4">
          {/* Generate New License */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
            <h3 className="text-sm font-semibold text-white mb-4">Generate New License</h3>
            <div className="flex flex-wrap gap-3 items-end">
              <div>
                <label className="block text-xs text-slate-400 mb-1">Plan Type</label>
                <select
                  value={newPlanType}
                  onChange={(e) => setNewPlanType(e.target.value as any)}
                  className="px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none"
                >
                  <option value="trial">Trial</option>
                  <option value="monthly">Monthly</option>
                  <option value="yearly">Yearly</option>
                  <option value="lifetime">Lifetime</option>
                </select>
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1">Duration (days)</label>
                <input
                  type="number"
                  value={newExpiryDays}
                  onChange={(e) => setNewExpiryDays(parseInt(e.target.value) || 30)}
                  className="w-20 px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none"
                />
              </div>
              <button
                onClick={generateLicense}
                disabled={generating}
                className="flex items-center gap-2 px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-white text-sm font-medium rounded-xl transition-all disabled:opacity-50"
              >
                <Plus className="w-4 h-4" />
                Generate
              </button>
            </div>

            {newKey && (
              <div className="mt-4 p-3 bg-emerald-500/5 border border-emerald-500/20 rounded-xl flex items-center gap-3">
                <code className="text-sm font-mono text-emerald-400 flex-1 tracking-widest">{newKey}</code>
                <button
                  onClick={() => navigator.clipboard.writeText(newKey)}
                  className="p-2 hover:bg-slate-700 rounded-lg transition-colors"
                >
                  <Copy className="w-4 h-4 text-slate-400" />
                </button>
              </div>
            )}
          </div>

          {/* Licenses List */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
            <div className="divide-y divide-slate-800/50">
              {licenses.map((license) => (
                <div key={license.id} className="p-4 flex items-center gap-3">
                  {statusIcon(license.status)}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <code className="text-sm font-mono text-white">{license.license_key}</code>
                      <span className="text-xs px-2 py-0.5 bg-slate-800 rounded text-slate-400 capitalize">
                        {license.plan_type}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-1">
                      Expires: {formatDateShort(license.expires_at)}
                    </p>
                  </div>
                  <div className="flex items-center gap-1">
                    {license.status !== 'active' && (
                      <button
                        onClick={() => toggleLicense(license, 'active')}
                        className="p-1.5 text-emerald-400 hover:bg-emerald-500/10 rounded-lg"
                        title="Activate"
                      >
                        <CheckCircle className="w-4 h-4" />
                      </button>
                    )}
                    {license.status !== 'suspended' && (
                      <button
                        onClick={() => toggleLicense(license, 'suspended')}
                        className="p-1.5 text-amber-400 hover:bg-amber-500/10 rounded-lg"
                        title="Suspend"
                      >
                        <Clock className="w-4 h-4" />
                      </button>
                    )}
                    {license.status !== 'revoked' && (
                      <button
                        onClick={() => toggleLicense(license, 'revoked')}
                        className="p-1.5 text-red-400 hover:bg-red-500/10 rounded-lg"
                        title="Revoke"
                      >
                        <Ban className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
              {licenses.length === 0 && (
                <div className="p-8 text-center text-slate-500 text-sm">No licenses generated yet.</div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Users Tab */}
      {tab === 'users' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
          <div className="divide-y divide-slate-800/50">
            {users.map((u) => (
              <div key={u.id} className="p-4 flex items-center gap-3">
                <div className="w-8 h-8 bg-slate-700 rounded-full flex items-center justify-center text-xs font-bold text-white">
                  {(u.full_name || u.email)[0].toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-white truncate">
                    {u.full_name || 'No name'}
                  </p>
                  <p className="text-xs text-slate-500 truncate">{u.email}</p>
                </div>
                <span
                  className={`text-xs font-bold px-2 py-0.5 rounded ${
                    u.role === 'admin' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {u.role}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Sessions Tab */}
      {tab === 'sessions' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center">
          <Activity className="w-8 h-8 text-slate-600 mx-auto mb-3" />
          <p className="text-lg text-white font-bold">{activeSessions}</p>
          <p className="text-sm text-slate-400">Active bot sessions right now</p>
        </div>
      )}
    </div>
  );
}
