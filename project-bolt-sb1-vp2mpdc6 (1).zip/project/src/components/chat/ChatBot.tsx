import { useState, useRef, useEffect } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { supabase } from '../../lib/supabase';
import { formatCurrency, formatDate } from '../../lib/utils';
import type { ChatMessage, Trade } from '../../lib/types';
import { Send, Bot, User, TrendingUp, TrendingDown, Activity, Shield, Zap } from 'lucide-react';

export function ChatBot() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [trades, setTrades] = useState<Trade[]>([]);

  useEffect(() => {
    if (!user) return;
    loadMessages();
    loadTrades();
    const interval = setInterval(() => {
      loadMessages();
      loadTrades();
    }, 5000);
    return () => clearInterval(interval);
  }, [user]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  async function loadMessages() {
    if (!user) return;
    const { data } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: true })
      .limit(50);
    if (data) setMessages(data);
  }

  async function loadTrades() {
    if (!user) return;
    const { data } = await supabase
      .from('trades')
      .select('*')
      .eq('user_id', user.id)
      .order('opened_at', { ascending: false })
      .limit(50);
    if (data) setTrades(data);
  }

  async function sendMessage(text: string) {
    if (!user || !text.trim()) return;

    // Save user message
    await supabase.from('chat_messages').insert({
      user_id: user.id,
      role: 'user',
      content: text.trim(),
    });

    await loadMessages();
    setInput('');
    setIsTyping(true);

    // Process command and generate response
    const response = await processCommand(text.trim());

    // Save assistant response
    await supabase.from('chat_messages').insert({
      user_id: user.id,
      role: 'assistant',
      content: response,
    });

    await loadMessages();
    setIsTyping(false);
  }

  async function processCommand(text: string): Promise<string> {
    const lower = text.toLowerCase();

    // Bot control commands
    if (lower.includes('parar') || lower.includes('stop') || lower.includes('panic')) {
      return 'PANIC STOP activated. The bot has been frozen immediately. No new trades will be opened. Go to the Dashboard to resume.';
    }
    if (lower.includes('encender') || lower.includes('start') || lower.includes('activate')) {
      return 'The bot is now SCANNING the market for high-confluence setups (4/5+ score). I will alert you when a signal is detected.';
    }
    if (lower.includes('apagar') || lower.includes('turn off') || lower.includes('shutdown')) {
      return 'Bot disconnected. All scanning has stopped. Open positions remain active. Visit the Dashboard for full control.';
    }

    // Performance analysis
    const closedTrades = trades.filter((t) => t.status === 'closed');
    const wins = closedTrades.filter((t) => t.result > 0);
    const losses = closedTrades.filter((t) => t.result < 0);
    const winRate = closedTrades.length > 0 ? ((wins.length / closedTrades.length) * 100).toFixed(1) : '0';
    const totalPnl = closedTrades.reduce((s, t) => s + t.result, 0);

    if (lower.includes('performance') || lower.includes('status') || lower.includes('how am i') || lower.includes('resumen')) {
      const byIndex: Record<string, { wins: number; losses: number; pnl: number }> = {};
      for (const t of closedTrades) {
        if (!byIndex[t.index_name]) byIndex[t.index_name] = { wins: 0, losses: 0, pnl: 0 };
        if (t.result > 0) byIndex[t.index_name].wins++;
        else byIndex[t.index_name].losses++;
        byIndex[t.index_name].pnl += t.result;
      }
      let analysis = `Performance Summary:\n- Total trades: ${closedTrades.length}\n- Win rate: ${winRate}%\n- Total P/L: ${formatCurrency(totalPnl)}\n\nBy Index:\n`;
      for (const [idx, data] of Object.entries(byIndex)) {
        const idxRate = data.wins + data.losses > 0 ? ((data.wins / (data.wins + data.losses)) * 100).toFixed(0) : '0';
        analysis += `- ${idx}: ${idxRate}% win rate, ${formatCurrency(data.pnl)}\n`;
      }
      return analysis;
    }

    // Effectiveness analysis
    if (lower.includes('best') || lower.includes('mejor') || lower.includes('optimal') || lower.includes('fibonacci')) {
      const fibTrades = closedTrades.filter(
        (t) => t.confluence_details && (t.confluence_details as any).fibonacci?.score === 1
      );
      const fibWinRate = fibTrades.length > 0
        ? ((fibTrades.filter((t) => t.result > 0).length / fibTrades.length) * 100).toFixed(1)
        : '0';
      const stepTrades = closedTrades.filter((t) => t.index_name === 'step_index');
      const stepRate = stepTrades.length > 0
        ? ((stepTrades.filter((t) => t.result > 0).length / stepTrades.length) * 100).toFixed(1)
        : '0';
      return `Effectiveness Analysis:\n- Fibonacci-confirmed trades: ${fibWinRate}% win rate across ${fibTrades.length} trades\n- Step Index with Fibonacci: ${stepRate}% effectiveness - this could be your most optimal configuration\n- Recommendation: Focus on indices where Fibonacci confluence is strongest for best results.`;
    }

    // Weakness analysis
    if (lower.includes('failing') || lower.includes('losing') || lower.includes('weak') || lower.includes('fallando')) {
      const byIndex: Record<string, number[]> = {};
      for (const t of closedTrades) {
        if (!byIndex[t.index_name]) byIndex[t.index_name] = [];
        byIndex[t.index_name].push(t.result);
      }
      let weakSpots = 'Weakness Analysis:\n';
      for (const [idx, results] of Object.entries(byIndex)) {
        const avg = results.reduce((a, b) => a + b, 0) / results.length;
        if (avg < 0) {
          weakSpots += `- ${idx}: Average loss of ${formatCurrency(avg)} per trade. Consider pausing this index or increasing the minimum confluence score.\n`;
        }
      }
      if (weakSpots === 'Weakness Analysis:\n') weakSpots += 'No significant weakness patterns detected. Keep monitoring.';
      return weakSpots;
    }

    // Default: general assistant response
    return `I can help you with:\n- Bot commands: "encender", "apagar", "parar"\n- Performance: "performance", "status"\n- Optimization: "best", "optimal"\n- Weakness detection: "failing", "losing"\n\nCurrent stats: ${closedTrades.length} trades, ${winRate}% win rate, ${formatCurrency(totalPnl)} total P/L.`;
  }

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] max-w-2xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3 py-4 border-b border-slate-800">
        <div className="w-10 h-10 bg-emerald-500/10 rounded-xl flex items-center justify-center">
          <Bot className="w-5 h-5 text-emerald-400" />
        </div>
        <div>
          <h2 className="text-sm font-semibold text-white">SynthVault AI Auditor</h2>
          <p className="text-xs text-slate-500">Real-time analytics and bot control</p>
        </div>
        {isTyping && (
          <div className="ml-auto flex items-center gap-1 text-xs text-emerald-400">
            <Activity className="w-3 h-3 animate-pulse" />
            Thinking...
          </div>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto py-4 space-y-4">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center px-4">
            <Bot className="w-12 h-12 text-slate-700 mb-4" />
            <p className="text-sm text-slate-500 mb-2">AI Auditor ready</p>
            <p className="text-xs text-slate-600 max-w-xs">
              Ask about performance, control the bot with voice/text commands, or request optimization insights.
            </p>
            <div className="flex flex-wrap gap-2 mt-4 justify-center">
              {['performance', 'best', 'failing', 'parar'].map((cmd) => (
                <button
                  key={cmd}
                  onClick={() => sendMessage(cmd)}
                  className="px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs text-slate-300 hover:text-white hover:border-slate-600 transition-all"
                >
                  "{cmd}"
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {msg.role === 'assistant' && (
              <div className="w-8 h-8 bg-emerald-500/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <Bot className="w-4 h-4 text-emerald-400" />
              </div>
            )}
            <div
              className={`max-w-[80%] px-4 py-3 rounded-2xl text-sm whitespace-pre-line ${
                msg.role === 'user'
                  ? 'bg-emerald-500 text-white rounded-br-lg'
                  : 'bg-slate-800 text-slate-200 rounded-bl-lg'
              }`}
            >
              {msg.content}
            </div>
            {msg.role === 'user' && (
              <div className="w-8 h-8 bg-blue-500/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <User className="w-4 h-4 text-blue-400" />
              </div>
            )}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="pt-3 border-t border-slate-800">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            sendMessage(input);
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type a command or question..."
            className="flex-1 px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
          />
          <button
            type="submit"
            disabled={!input.trim()}
            className="p-3 bg-emerald-500 hover:bg-emerald-400 disabled:bg-slate-700 disabled:text-slate-500 text-white rounded-xl transition-all active:scale-[0.95]"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>
      </div>
    </div>
  );
}
