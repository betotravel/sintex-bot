import { useState, useEffect } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { supabase } from '../../lib/supabase';
import { formatCurrency, formatDate } from '../../lib/utils';
import type { Trade } from '../../lib/types';
import { TrendingUp, TrendingDown, Filter, Download } from 'lucide-react';

export function TradeHistory() {
  const { user } = useAuth();
  const [trades, setTrades] = useState<Trade[]>([]);
  const [filter, setFilter] = useState<'all' | 'buy' | 'sell'>('all');
  const [filterIndex, setFilterIndex] = useState('all');

  useEffect(() => {
    if (!user) return;
    const fetch = async () => {
      let query = supabase
        .from('trades')
        .select('*')
        .eq('user_id', user.id)
        .order('opened_at', { ascending: false });

      if (filter !== 'all') query = query.eq('trade_type', filter);
      if (filterIndex !== 'all') query = query.eq('index_name', filterIndex);

      const { data } = await query;
      setTrades(data ?? []);
    };
    fetch();
    const interval = setInterval(fetch, 15000);
    return () => clearInterval(interval);
  }, [user, filter, filterIndex]);

  const totalPnl = trades.filter((t) => t.status === 'closed').reduce((s, t) => s + t.result, 0);
  const wins = trades.filter((t) => t.status === 'closed' && t.result > 0).length;
  const losses = trades.filter((t) => t.status === 'closed' && t.result < 0).length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Trade History</h1>
        <p className="text-slate-400 text-sm mt-1">Complete log of all trading activity</p>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-center">
          <p className="text-xs text-slate-500 mb-1">Total P/L</p>
          <p className={`text-lg font-bold ${totalPnl >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
            {formatCurrency(totalPnl)}
          </p>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-center">
          <p className="text-xs text-slate-500 mb-1">Wins</p>
          <p className="text-lg font-bold text-emerald-400">{wins}</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-center">
          <p className="text-xs text-slate-500 mb-1">Losses</p>
          <p className="text-lg font-bold text-red-400">{losses}</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        <div className="flex bg-slate-800 rounded-xl p-1">
          {(['all', 'buy', 'sell'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                filter === f
                  ? f === 'buy' ? 'bg-emerald-500 text-white' : f === 'sell' ? 'bg-red-500 text-white' : 'bg-slate-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {f === 'all' ? 'All' : f === 'buy' ? 'Buy' : 'Sell'}
            </button>
          ))}
        </div>
        <select
          value={filterIndex}
          onChange={(e) => setFilterIndex(e.target.value)}
          className="px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
        >
          <option value="all">All Indices</option>
          <option value="boom500">Boom 500</option>
          <option value="boom1000">Boom 1000</option>
          <option value="crash500">Crash 500</option>
          <option value="crash1000">Crash 1000</option>
          <option value="step_index">Step Index</option>
        </select>
      </div>

      {/* Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
        {/* Desktop Table */}
        <div className="hidden sm:block overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-800">
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-500">Date</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-500">Index</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-slate-500">Type</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-slate-500">Lots</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-slate-500">Margin</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-slate-500">Entry</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-slate-500">Exit</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-slate-500">Score</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-slate-500">Result</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {trades.map((trade) => (
                <tr key={trade.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="px-4 py-3 text-sm text-slate-300">{formatDate(trade.opened_at)}</td>
                  <td className="px-4 py-3 text-sm text-white font-medium">{trade.index_name}</td>
                  <td className="px-4 py-3">
                    <span
                      className={`inline-flex items-center gap-1 text-xs font-bold px-2 py-0.5 rounded-lg ${
                        trade.trade_type === 'buy'
                          ? 'bg-emerald-500/10 text-emerald-400'
                          : 'bg-red-500/10 text-red-400'
                      }`}
                    >
                      {trade.trade_type === 'buy' ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                      {trade.trade_type.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm text-slate-300 text-right">{trade.lot_size}</td>
                  <td className="px-4 py-3 text-sm text-slate-300 text-right">{trade.margin || '---'}</td>
                  <td className="px-4 py-3 text-sm text-slate-300 text-right font-mono">{trade.entry_price}</td>
                  <td className="px-4 py-3 text-sm text-slate-300 text-right font-mono">{trade.exit_price || '---'}</td>
                  <td className="px-4 py-3 text-right">
                    <span
                      className={`text-sm font-bold ${
                        trade.confluence_score >= 4 ? 'text-emerald-400' : 'text-amber-400'
                      }`}
                    >
                      {trade.confluence_score}/5
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <span
                      className={`text-sm font-bold ${
                        trade.result > 0 ? 'text-emerald-400' : trade.result < 0 ? 'text-red-400' : 'text-slate-500'
                      }`}
                    >
                      {trade.status === 'open' ? 'OPEN' : formatCurrency(trade.result)}
                    </span>
                  </td>
                </tr>
              ))}
              {trades.length === 0 && (
                <tr>
                  <td colSpan={9} className="px-4 py-8 text-center text-slate-500 text-sm">
                    No trades yet. Start the bot to begin trading.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Mobile Cards */}
        <div className="sm:hidden divide-y divide-slate-800/50">
          {trades.map((trade) => (
            <div key={trade.id} className="p-4 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span
                    className={`inline-flex items-center gap-1 text-xs font-bold px-2 py-0.5 rounded-lg ${
                      trade.trade_type === 'buy'
                        ? 'bg-emerald-500/10 text-emerald-400'
                        : 'bg-red-500/10 text-red-400'
                    }`}
                  >
                    {trade.trade_type.toUpperCase()}
                  </span>
                  <span className="text-sm font-medium text-white">{trade.index_name}</span>
                </div>
                <span
                  className={`text-sm font-bold ${
                    trade.result > 0 ? 'text-emerald-400' : trade.result < 0 ? 'text-red-400' : 'text-slate-500'
                  }`}
                >
                  {trade.status === 'open' ? 'OPEN' : formatCurrency(trade.result)}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>{formatDate(trade.opened_at)}</span>
                <span>{trade.lot_size} lots | Score {trade.confluence_score}/5</span>
              </div>
            </div>
          ))}
          {trades.length === 0 && (
            <div className="p-8 text-center text-slate-500 text-sm">
              No trades yet. Start the bot to begin trading.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
