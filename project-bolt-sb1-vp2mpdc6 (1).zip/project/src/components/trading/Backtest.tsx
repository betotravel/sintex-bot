import { useState, useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { calculateConfluence, calculateEMA, calculateRSI, calculateFibonacci } from '../../lib/indicators';
import { SYNTHETIC_INDICES } from '../../lib/types';
import type { Candle, ConfluenceResult } from '../../lib/types';
import { Play, BarChart3, TrendingUp, Target, AlertTriangle } from 'lucide-react';

function generateHistoricalCandles(
  symbol: string,
  days: number,
  seed: number
): Candle[] {
  const candles: Candle[] = [];
  let price = 1000 + seed * 100;
  const now = Date.now();
  const volatility = symbol.includes('boom') ? 8 : symbol.includes('crash') ? 8 : 2;
  const spikeChance = symbol.includes('boom') || symbol.includes('crash') ? 0.03 : 0;

  const rng = (n: number) => {
    const x = Math.sin(n * 9301 + 49297) * 233280;
    return x - Math.floor(x);
  };

  for (let i = days * 1440; i >= 0; i--) {
    const epoch = now - i * 60000;
    const r = rng(epoch / 1000 + seed);
    let change = (r - 0.5) * volatility;

    // Boom spikes up, Crash spikes down
    if (rng(epoch / 500 + seed * 2) < spikeChance) {
      change *= symbol.includes('boom') ? 8 : -8;
    }

    price = Math.max(100, price + change);
    const high = price + Math.abs(change) * rng(epoch / 200 + seed * 3);
    const low = price - Math.abs(change) * rng(epoch / 300 + seed * 4);
    candles.push({
      epoch,
      open: price,
      high,
      low,
      close: price + change * 0.5,
    });
  }
  return candles;
}

export function Backtest() {
  const [selectedIndex, setSelectedIndex] = useState(SYNTHETIC_INDICES[0].id);
  const [days, setDays] = useState(30);
  const [running, setRunning] = useState(false);
  const [results, setResults] = useState<{
    trades: { type: string; entry: number; exit: number; pnl: number; score: number; date: string }[];
    winRate: number;
    totalPnl: number;
    totalTrades: number;
    equityCurve: { date: string; balance: number }[];
  } | null>(null);

  const runBacktest = () => {
    setRunning(true);

    setTimeout(() => {
      const indexInfo = SYNTHETIC_INDICES.find((i) => i.id === selectedIndex)!;
      const candles = generateHistoricalCandles(indexInfo.symbol, days, selectedIndex.length);
      const trades: { type: string; entry: number; exit: number; pnl: number; score: number; date: string }[] = [];
      let balance = 10000;
      const equityCurve: { date: string; balance: number }[] = [{ date: 'Start', balance }];

      for (let i = 60; i < candles.length - 10; i += 5) {
        const window = candles.slice(i - 60, i);
        const result = calculateConfluence(window, selectedIndex);

        if (result.totalScore >= 4 && result.signal) {
          const entryPrice = candles[i].close;
          const exitIdx = Math.min(i + 10, candles.length - 1);
          const exitPrice = candles[exitIdx].close;

          const pnl =
            result.signal === 'buy'
              ? (exitPrice - entryPrice) * 2
              : (entryPrice - exitPrice) * 2;

          balance += pnl;
          trades.push({
            type: result.signal,
            entry: entryPrice,
            exit: exitPrice,
            pnl,
            score: result.totalScore,
            date: new Date(candles[i].epoch).toLocaleDateString(),
          });
          equityCurve.push({
            date: new Date(candles[i].epoch).toLocaleDateString(),
            balance: Math.round(balance * 100) / 100,
          });
          i = exitIdx;
        }
      }

      const wins = trades.filter((t) => t.pnl > 0).length;
      const totalPnl = trades.reduce((s, t) => s + t.pnl, 0);

      setResults({
        trades,
        winRate: trades.length > 0 ? (wins / trades.length) * 100 : 0,
        totalPnl,
        totalTrades: trades.length,
        equityCurve,
      });
      setRunning(false);
    }, 800);
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Backtesting Simulator</h1>
        <p className="text-slate-400 text-sm mt-1">
          Test the confluence algorithm against historical data
        </p>
      </div>

      {/* Configuration */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
        <h3 className="text-sm font-semibold text-white mb-4">Configuration</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Index</label>
            <select
              value={selectedIndex}
              onChange={(e) => setSelectedIndex(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
            >
              {SYNTHETIC_INDICES.map((idx) => (
                <option key={idx.id} value={idx.id}>{idx.label}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1.5">Days</label>
            <select
              value={days}
              onChange={(e) => setDays(parseInt(e.target.value))}
              className="w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
            >
              <option value={7}>7 days</option>
              <option value={14}>14 days</option>
              <option value={30}>30 days</option>
              <option value={60}>60 days</option>
              <option value={90}>90 days</option>
            </select>
          </div>
          <button
            onClick={runBacktest}
            disabled={running}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 disabled:bg-slate-700 text-white text-sm font-medium rounded-xl transition-all shadow-lg shadow-emerald-500/25"
          >
            {running ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Play className="w-4 h-4" />
            )}
            {running ? 'Running...' : 'Run Backtest'}
          </button>
        </div>
      </div>

      {/* Results */}
      {results && (
        <>
          {/* Summary */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-center">
              <Target className="w-5 h-5 text-emerald-400 mx-auto mb-2" />
              <p className={`text-2xl font-bold ${results.winRate >= 50 ? 'text-emerald-400' : 'text-red-400'}`}>
                {results.winRate.toFixed(1)}%
              </p>
              <p className="text-xs text-slate-500">Win Rate</p>
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-center">
              <BarChart3 className="w-5 h-5 text-blue-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-white">{results.totalTrades}</p>
              <p className="text-xs text-slate-500">Total Trades</p>
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-center">
              <TrendingUp className="w-5 h-5 text-amber-400 mx-auto mb-2" />
              <p className={`text-2xl font-bold ${results.totalPnl >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                ${results.totalPnl.toFixed(2)}
              </p>
              <p className="text-xs text-slate-500">Total P/L</p>
            </div>
          </div>

          {/* Effectiveness Banner */}
          <div
            className={`p-4 rounded-2xl border ${
              results.winRate >= 70
                ? 'bg-emerald-500/5 border-emerald-500/20'
                : results.winRate >= 50
                ? 'bg-amber-500/5 border-amber-500/20'
                : 'bg-red-500/5 border-red-500/20'
            }`}
          >
            <div className="flex items-center gap-3">
              {results.winRate >= 70 ? (
                <TrendingUp className="w-6 h-6 text-emerald-400" />
              ) : (
                <AlertTriangle className="w-6 h-6 text-amber-400" />
              )}
              <div>
                <p className={`text-sm font-bold ${results.winRate >= 70 ? 'text-emerald-400' : results.winRate >= 50 ? 'text-amber-400' : 'text-red-400'}`}>
                  {results.winRate >= 70
                    ? 'High Effectiveness'
                    : results.winRate >= 50
                    ? 'Moderate Effectiveness'
                    : 'Low Effectiveness'}
                </p>
                <p className="text-xs text-slate-400">
                  {results.winRate >= 70
                    ? 'The confluence algorithm shows strong performance on this index.'
                    : results.winRate >= 50
                    ? 'Consider adjusting the minimum confluence score to improve results.'
                    : 'This index may not be ideal for the current algorithm configuration.'}
                </p>
              </div>
            </div>
          </div>

          {/* Equity Curve */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
            <h3 className="text-sm font-semibold text-white mb-4">Equity Curve</h3>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={results.equityCurve}>
                  <defs>
                    <linearGradient id="backtestGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={results.totalPnl >= 0 ? '#34d399' : '#f87171'} stopOpacity={0.3} />
                      <stop offset="100%" stopColor={results.totalPnl >= 0 ? '#34d399' : '#f87171'} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                  <YAxis
                    tick={{ fontSize: 10, fill: '#64748b' }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(v) => `$${v}`}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      border: '1px solid #1e293b',
                      borderRadius: '12px',
                      fontSize: '12px',
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="balance"
                    stroke={results.totalPnl >= 0 ? '#34d399' : '#f87171'}
                    strokeWidth={2}
                    fill="url(#backtestGradient)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Trade Log */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-slate-800">
              <h3 className="text-sm font-semibold text-white">Simulated Trades</h3>
            </div>
            <div className="max-h-64 overflow-y-auto divide-y divide-slate-800/50">
              {results.trades.map((trade, idx) => (
                <div key={idx} className="px-4 py-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span
                      className={`text-xs font-bold px-2 py-0.5 rounded ${
                        trade.type === 'buy'
                          ? 'bg-emerald-500/10 text-emerald-400'
                          : 'bg-red-500/10 text-red-400'
                      }`}
                    >
                      {trade.type.toUpperCase()}
                    </span>
                    <div>
                      <p className="text-xs text-slate-400">{trade.date}</p>
                      <p className="text-xs text-slate-500">Score: {trade.score}/5</p>
                    </div>
                  </div>
                  <span
                    className={`text-sm font-bold ${trade.pnl >= 0 ? 'text-emerald-400' : 'text-red-400'}`}
                  >
                    {trade.pnl >= 0 ? '+' : ''}{trade.pnl.toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
