export type BotStatus = 'running' | 'off' | 'paused';
export type Environment = 'demo' | 'real';
export type TradeType = 'buy' | 'sell';
export type TradeStatus = 'open' | 'closed' | 'cancelled';
export type LicenseStatus = 'active' | 'suspended' | 'revoked' | 'expired';
export type PlanType = 'trial' | 'monthly' | 'yearly' | 'lifetime';
export type UserRole = 'admin' | 'user';

export const SYNTHETIC_INDICES = [
  { id: 'boom500', label: 'Boom 500', symbol: 'BOOM500N' },
  { id: 'boom1000', label: 'Boom 1000', symbol: 'BOOM1000N' },
  { id: 'crash500', label: 'Crash 500', symbol: 'CRASH500N' },
  { id: 'crash1000', label: 'Crash 1000', symbol: 'CRASH1000N' },
  { id: 'step_index', label: 'Step Index', symbol: 'stpRNG50N' },
] as const;

export type SyntheticIndexId = (typeof SYNTHETIC_INDICES)[number]['id'];

export interface Profile {
  id: string;
  user_id: string;
  email: string;
  full_name: string;
  role: UserRole;
  deriv_demo_token_encrypted: string;
  deriv_real_token_encrypted: string;
  created_at: string;
  updated_at: string;
}

export interface License {
  id: string;
  license_key: string;
  user_id: string | null;
  status: LicenseStatus;
  plan_type: PlanType;
  expires_at: string;
  created_at: string;
  activated_at: string | null;
  created_by: string | null;
}

export interface BotConfig {
  id: string;
  user_id: string;
  environment: Environment;
  selected_indices: SyntheticIndexId[];
  lot_size: number;
  daily_stop_loss: number;
  daily_take_profit: number;
  confluence_min_score: number;
  enable_trailing_stop: boolean;
  enable_breakeven: boolean;
  trailing_stop_pips: number;
  breakeven_at_pips: number;
  max_consecutive_losses: number;
  pause_after_losses_minutes: number;
  enable_anti_fakeout: boolean;
  updated_at: string;
}

export interface Trade {
  id: string;
  user_id: string;
  index_name: string;
  trade_type: TradeType;
  lot_size: number;
  margin: number;
  entry_price: number;
  exit_price: number | null;
  result: number;
  confluence_score: number;
  confluence_details: ConfluenceDetails;
  environment: Environment;
  status: TradeStatus;
  opened_at: string;
  closed_at: string | null;
}

export interface BotSession {
  id: string;
  user_id: string;
  status: BotStatus;
  environment: Environment;
  connected_at: string | null;
  disconnected_at: string | null;
  daily_pnl: number;
  daily_trades: number;
  consecutive_losses: number;
  paused_until: string | null;
  created_at: string;
  updated_at: string;
}

export interface ChatMessage {
  id: string;
  user_id: string;
  role: 'user' | 'assistant';
  content: string;
  metadata: Record<string, unknown>;
  created_at: string;
}

export interface ConfluenceDetails {
  price_action: { score: number; reason: string };
  support_resistance: { score: number; reason: string };
  fibonacci: { score: number; reason: string };
  spike_reaction: { score: number; reason: string };
  indicators: { score: number; reason: string };
}

export interface Candle {
  epoch: number;
  open: number;
  high: number;
  low: number;
  close: number;
}

export interface Tick {
  epoch: number;
  quote: number;
  symbol: string;
}
