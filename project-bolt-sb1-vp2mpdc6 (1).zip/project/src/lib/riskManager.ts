import type { BotConfig } from './types';

export interface RiskDecision {
  shouldClose: boolean;
  reason: string;
  shouldPause: boolean;
  shouldMoveToBreakeven: boolean;
  newTrailingStop: number | null;
}

export class RiskManager {
  private config: BotConfig;
  private entryPrice: number = 0;
  private currentPrice: number = 0;
  private tradeDirection: 'buy' | 'sell' = 'buy';
  private currentPnl: number = 0;
  private consecutiveLosses: number = 0;
  private dailyPnl: number = 0;
  private highestProfit: number = 0;
  private isPaused: boolean = false;
  private pauseEndTime: Date | null = null;

  constructor(config: BotConfig) {
    this.config = config;
  }

  updateConfig(config: BotConfig) {
    this.config = config;
  }

  openTrade(entryPrice: number, direction: 'buy' | 'sell') {
    this.entryPrice = entryPrice;
    this.tradeDirection = direction;
    this.highestProfit = 0;
  }

  updatePrice(price: number) {
    this.currentPrice = price;
    if (this.tradeDirection === 'buy') {
      this.currentPnl = (price - this.entryPrice) * this.config.lot_size * 10;
    } else {
      this.currentPnl = (this.entryPrice - price) * this.config.lot_size * 10;
    }
    if (this.currentPnl > this.highestProfit) {
      this.highestProfit = this.currentPnl;
    }
  }

  updateConsecutiveLosses(losses: number) {
    this.consecutiveLosses = losses;
  }

  updateDailyPnl(pnl: number) {
    this.dailyPnl = pnl;
  }

  evaluate(confluenceScore: number): RiskDecision {
    const result: RiskDecision = {
      shouldClose: false,
      reason: '',
      shouldPause: false,
      shouldMoveToBreakeven: false,
      newTrailingStop: null,
    };

    // Check if paused
    if (this.isPaused) {
      if (this.pauseEndTime && new Date() < this.pauseEndTime) {
        result.shouldPause = true;
        result.reason = `Bot paused until ${this.pauseEndTime.toLocaleTimeString()}`;
        return result;
      }
      this.isPaused = false;
    }

    // Daily stop loss check
    if (this.dailyPnl <= -this.config.daily_stop_loss) {
      result.shouldClose = true;
      result.reason = `Daily stop loss reached: -$${this.config.daily_stop_loss}`;
      return result;
    }

    // Daily take profit check
    if (this.dailyPnl >= this.config.daily_take_profit) {
      result.shouldClose = true;
      result.reason = `Daily take profit reached: +$${this.config.daily_take_profit}`;
      return result;
    }

    // Confluence score dropped below 2 while in trade
    if (confluenceScore < 2 && this.entryPrice > 0) {
      result.shouldClose = true;
      result.reason = `Confluence score dropped to ${confluenceScore} - closing to protect capital`;
      return result;
    }

    // Consecutive losses filter
    if (this.consecutiveLosses >= this.config.max_consecutive_losses) {
      this.isPaused = true;
      this.pauseEndTime = new Date(Date.now() + this.config.pause_after_losses_minutes * 60000);
      result.shouldPause = true;
      result.reason = `${this.consecutiveLosses} consecutive losses - pausing for ${this.config.pause_after_losses_minutes} minutes`;
      return result;
    }

    // Breakeven logic
    if (
      this.config.enable_breakeven &&
      this.currentPnl >= this.config.breakeven_at_pips &&
      this.entryPrice > 0
    ) {
      result.shouldMoveToBreakeven = true;
      result.reason = `Moving to breakeven at +${this.config.breakeven_at_pips} pips`;
    }

    // Trailing stop logic
    if (
      this.config.enable_trailing_stop &&
      this.highestProfit >= this.config.trailing_stop_pips &&
      this.currentPnl < this.highestProfit - this.config.trailing_stop_pips &&
      this.entryPrice > 0
    ) {
      result.shouldClose = true;
      result.reason = `Trailing stop triggered: profit dropped from $${this.highestProfit.toFixed(2)} to $${this.currentPnl.toFixed(2)}`;
      return result;
    }

    return result;
  }

  isPausedNow(): boolean {
    if (!this.isPaused) return false;
    if (this.pauseEndTime && new Date() >= this.pauseEndTime) {
      this.isPaused = false;
      return false;
    }
    return true;
  }

  getPauseEndTime(): Date | null {
    return this.pauseEndTime;
  }

  getPnl(): number {
    return this.currentPnl;
  }
}
