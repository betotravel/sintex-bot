import type { Candle, ConfluenceDetails } from './types';

// EMA calculation
export function calculateEMA(closes: number[], period: number): number[] {
  const ema: number[] = [];
  const multiplier = 2 / (period + 1);
  ema[0] = closes.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = 1; i < closes.length; i++) {
    ema[i] = (closes[i] - ema[i - 1]) * multiplier + ema[i - 1];
  }
  return ema;
}

// RSI calculation
export function calculateRSI(closes: number[], period = 14): number[] {
  const rsi: number[] = [];
  const gains: number[] = [];
  const losses: number[] = [];

  for (let i = 1; i < closes.length; i++) {
    const change = closes[i] - closes[i - 1];
    gains.push(change > 0 ? change : 0);
    losses.push(change < 0 ? Math.abs(change) : 0);
  }

  if (gains.length < period) return [50];

  let avgGain = gains.slice(0, period).reduce((a, b) => a + b, 0) / period;
  let avgLoss = losses.slice(0, period).reduce((a, b) => a + b, 0) / period;

  for (let i = period; i < gains.length; i++) {
    avgGain = (avgGain * (period - 1) + gains[i]) / period;
    avgLoss = (avgLoss * (period - 1) + losses[i]) / period;
    const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
    rsi.push(100 - 100 / (1 + rs));
  }
  return rsi;
}

// Fibonacci retracement levels
export function calculateFibonacci(high: number, low: number): Record<string, number> {
  const diff = high - low;
  return {
    '0': high,
    '23.6': high - diff * 0.236,
    '38.2': high - diff * 0.382,
    '50': high - diff * 0.5,
    '61.8': high - diff * 0.618,
    '78.6': high - diff * 0.786,
    '100': low,
  };
}

// Find support and resistance levels
export function findSupportResistance(candles: Candle[]): {
  supports: number[];
  resistances: number[];
} {
  const supports: number[] = [];
  const resistances: number[] = [];
  const windowSize = 5;

  for (let i = windowSize; i < candles.length - windowSize; i++) {
    const slice = candles.slice(i - windowSize, i + windowSize + 1);
    const isSwingLow = slice.every((c, idx) => idx === windowSize || c.low >= slice[windowSize].low);
    const isSwingHigh = slice.every((c, idx) => idx === windowSize || c.high <= slice[windowSize].high);

    if (isSwingLow) supports.push(candles[i].low);
    if (isSwingHigh) resistances.push(candles[i].high);
  }

  // Cluster nearby levels
  const cluster = (levels: number[], threshold = 0.5): number[] => {
    if (levels.length === 0) return [];
    const sorted = [...levels].sort((a, b) => a - b);
    const clustered: number[] = [];
    let group = [sorted[0]];
    for (let i = 1; i < sorted.length; i++) {
      if (sorted[i] - sorted[i - 1] < threshold) {
        group.push(sorted[i]);
      } else {
        clustered.push(group.reduce((a, b) => a + b, 0) / group.length);
        group = [sorted[i]];
      }
    }
    clustered.push(group.reduce((a, b) => a + b, 0) / group.length);
    return clustered;
  };

  return {
    supports: cluster(supports),
    resistances: cluster(resistances),
  };
}

// Detect market structure (trending vs ranging)
export function analyzeMarketStructure(candles: Candle[]): {
  isTrending: boolean;
  direction: 'bullish' | 'bearish' | 'neutral';
} {
  if (candles.length < 20) return { isTrending: false, direction: 'neutral' };

  const recent = candles.slice(-20);
  const higherHighs = recent.every(
    (c, i) => i === 0 || c.high >= recent[i - 1].high * 0.999
  );
  const higherLows = recent.every(
    (c, i) => i === 0 || c.low >= recent[i - 1].low * 0.999
  );
  const lowerHighs = recent.every(
    (c, i) => i === 0 || c.high <= recent[i - 1].high * 1.001
  );
  const lowerLows = recent.every(
    (c, i) => i === 0 || c.low <= recent[i - 1].low * 1.001
  );

  if (higherHighs && higherLows) return { isTrending: true, direction: 'bullish' };
  if (lowerHighs && lowerLows) return { isTrending: true, direction: 'bearish' };
  return { isTrending: false, direction: 'neutral' };
}

// Detect spikes (for Boom/Crash indices)
export function detectSpike(candles: Candle[], threshold = 2.0): {
  isSpike: boolean;
  spikeDirection: 'up' | 'down' | null;
  spikeCandle: Candle | null;
} {
  if (candles.length < 2) return { isSpike: false, spikeDirection: null, spikeCandle: null };

  const lastCandle = candles[candles.length - 1];
  const prevCandle = candles[candles.length - 2];
  const avgRange =
    candles.slice(-10).reduce((sum, c) => sum + (c.high - c.low), 0) / 10;
  const currentRange = lastCandle.high - lastCandle.low;

  if (currentRange > avgRange * threshold) {
    const isUpSpike = lastCandle.close > lastCandle.open && lastCandle.close > prevCandle.high;
    const isDownSpike = lastCandle.close < lastCandle.open && lastCandle.close < prevCandle.low;
    return {
      isSpike: isUpSpike || isDownSpike,
      spikeDirection: isUpSpike ? 'up' : isDownSpike ? 'down' : null,
      spikeCandle: lastCandle,
    };
  }
  return { isSpike: false, spikeDirection: null, spikeCandle: null };
}

// Count pullback candles after spike
export function countPullbackCandles(
  candles: Candle[],
  direction: 'up' | 'down'
): number {
  let count = 0;
  for (let i = candles.length - 1; i >= Math.max(0, candles.length - 6); i--) {
    const c = candles[i];
    if (direction === 'up' && c.close < c.open) count++;
    else if (direction === 'down' && c.close > c.open) count++;
    else break;
  }
  return count;
}

export interface ConfluenceResult {
  totalScore: number;
  details: ConfluenceDetails;
  signal: 'buy' | 'sell' | null;
}

// Main confluence scoring engine
export function calculateConfluence(
  candles: Candle[],
  indexId: string
): ConfluenceResult {
  if (candles.length < 30) {
    return {
      totalScore: 0,
      details: {
        price_action: { score: 0, reason: 'Insufficient data' },
        support_resistance: { score: 0, reason: 'Insufficient data' },
        fibonacci: { score: 0, reason: 'Insufficient data' },
        spike_reaction: { score: 0, reason: 'Insufficient data' },
        indicators: { score: 0, reason: 'Insufficient data' },
      },
      signal: null,
    };
  }

  const closes = candles.map((c) => c.close);
  const currentPrice = closes[closes.length - 1];
  const structure = analyzeMarketStructure(candles);
  const sr = findSupportResistance(candles);
  const ema9 = calculateEMA(closes, 9);
  const ema21 = calculateEMA(closes, 21);
  const rsi = calculateRSI(closes);
  const currentRSI = rsi.length > 0 ? rsi[rsi.length - 1] : 50;
  const currentEma9 = ema9.length > 0 ? ema9[ema9.length - 1] : currentPrice;
  const currentEma21 = ema21.length > 0 ? ema21[ema21.length - 1] : currentPrice;
  const prevEma9 = ema9.length > 1 ? ema9[ema9.length - 2] : currentPrice;
  const prevEma21 = ema21.length > 1 ? ema21[ema21.length - 2] : currentPrice;

  // 1. Price Action (1 point)
  let paScore = 0;
  let paReason = '';
  if (structure.isTrending) {
    paScore = 1;
    paReason = `${structure.direction === 'bullish' ? 'Bullish' : 'Bearish'} trend confirmed`;
  } else {
    paReason = 'Market ranging - no entry';
  }

  // 2. Support/Resistance (1 point)
  let srScore = 0;
  let srReason = 'No key level nearby';
  const nearSupport = sr.supports.some((s) => Math.abs(currentPrice - s) / s < 0.003);
  const nearResistance = sr.resistances.some((r) => Math.abs(currentPrice - r) / r < 0.003);
  if (nearSupport || nearResistance) {
    srScore = 1;
    srReason = nearSupport ? 'At key support level' : 'At key resistance level';
  }

  // 3. Fibonacci (1 point) - 61.8% or 78.6% zone
  let fibScore = 0;
  let fibReason = 'Outside Fibonacci zone';
  const recentHigh = Math.max(...candles.slice(-30).map((c) => c.high));
  const recentLow = Math.min(...candles.slice(-30).map((c) => c.low));
  const fib = calculateFibonacci(recentHigh, recentLow);
  const fibZone61 = Math.abs(currentPrice - fib['61.8']) / currentPrice < 0.005;
  const fibZone78 = Math.abs(currentPrice - fib['78.6']) / currentPrice < 0.005;
  if (fibZone61 || fibZone78) {
    fibScore = 1;
    fibReason = `In Fibonacci golden zone (${fibZone61 ? '61.8' : '78.6'}%)`;
  }

  // 4. Spike Reaction (1 point)
  let spikeScore = 0;
  let spikeReason = 'No spike detected';
  const spike = detectSpike(candles);
  const isBoomCrash = ['boom500', 'boom1000', 'crash500', 'crash1000'].includes(indexId);
  if (isBoomCrash && spike.isSpike) {
    const pullbackCandles = countPullbackCandles(candles, spike.spikeDirection!);
    if (pullbackCandles >= 3 && pullbackCandles <= 5) {
      spikeScore = 1;
      spikeReason = `Pullback of ${pullbackCandles} candles after spike - optimal entry`;
    } else {
      spikeReason = `Pullback of ${pullbackCandles} candles - not in 3-5 range`;
    }
  }

  // 5. Indicators (1 point)
  let indScore = 0;
  let indReason = 'No indicator confirmation';
  const emaCross = prevEma9 <= prevEma21 && currentEma9 > currentEma21;
  const emaCrossDown = prevEma9 >= prevEma21 && currentEma9 < currentEma21;
  const rsiOverbought = currentRSI > 70;
  const rsiOversold = currentRSI < 30;

  if (emaCross || emaCrossDown) {
    indScore = 1;
    indReason = `EMA crossover detected (${emaCross ? 'bullish' : 'bearish'})`;
  } else if (rsiOverbought || rsiOversold) {
    indScore = 1;
    indReason = `RSI at extreme (${currentRSI.toFixed(1)})`;
  }

  const totalScore = paScore + srScore + fibScore + spikeScore + indScore;
  const details: ConfluenceDetails = {
    price_action: { score: paScore, reason: paReason },
    support_resistance: { score: srScore, reason: srReason },
    fibonacci: { score: fibScore, reason: fibReason },
    spike_reaction: { score: spikeScore, reason: spikeReason },
    indicators: { score: indScore, reason: indReason },
  };

  let signal: 'buy' | 'sell' | null = null;
  if (totalScore >= 4) {
    if (structure.direction === 'bullish' || emaCross || rsiOversold) {
      signal = 'buy';
    } else if (structure.direction === 'bearish' || emaCrossDown || rsiOverbought) {
      signal = 'sell';
    }
    // For Boom indices, default is buy; for Crash, default is sell
    if (!signal) {
      if (indexId.startsWith('boom')) signal = 'buy';
      else if (indexId.startsWith('crash')) signal = 'sell';
      else signal = ema9[ema9.length - 1] > ema21[ema21.length - 1] ? 'buy' : 'sell';
    }
  }

  return { totalScore, details, signal };
}
