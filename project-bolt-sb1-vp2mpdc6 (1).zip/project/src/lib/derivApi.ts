import type { Candle, Tick } from './types';

const DERIV_WS_URL = 'wss://ws.binaryws.com/websockets/v3?app_id=1089';

type MessageHandler = (data: Record<string, unknown>) => void;

export class DerivAPI {
  private ws: WebSocket | null = null;
  private handlers: Map<string, MessageHandler[]> = new Map();
  private pingInterval: ReturnType<typeof setInterval> | null = null;
  private reconnectAttempts = 0;
  private maxReconnect = 5;
  private token: string = '';
  private _connected = false;
  private onConnectCallback?: () => void;
  private onDisconnectCallback?: () => void;

  get connected() {
    return this._connected;
  }

  connect(token: string): Promise<void> {
    this.token = token;
    return new Promise((resolve, reject) => {
      try {
        this.ws = new WebSocket(DERIV_WS_URL);

        this.ws.onopen = () => {
          this._connected = true;
          this.reconnectAttempts = 0;
          this.authorize(token);
          this.startPing();
          this.onConnectCallback?.();
          resolve();
        };

        this.ws.onmessage = (event) => {
          const data = JSON.parse(event.data);
          this.dispatch(data);
        };

        this.ws.onerror = (err) => {
          reject(err);
        };

        this.ws.onclose = () => {
          this._connected = false;
          this.onDisconnectCallback?.();
          this.attemptReconnect();
        };
      } catch (err) {
        reject(err);
      }
    });
  }

  disconnect() {
    this.reconnectAttempts = this.maxReconnect;
    if (this.pingInterval) clearInterval(this.pingInterval);
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this._connected = false;
  }

  onConnect(cb: () => void) {
    this.onConnectCallback = cb;
  }

  onDisconnect(cb: () => void) {
    this.onDisconnectCallback = cb;
  }

  private authorize(token: string) {
    this.send({ authorize: token });
  }

  private startPing() {
    this.pingInterval = setInterval(() => {
      this.send({ ping: 1 });
    }, 25000);
  }

  private attemptReconnect() {
    if (this.reconnectAttempts >= this.maxReconnect) return;
    this.reconnectAttempts++;
    setTimeout(() => {
      this.connect(this.token);
    }, 2000 * this.reconnectAttempts);
  }

  private dispatch(data: Record<string, unknown>) {
    const msgType = data.msg_type as string;
    const handlers = this.handlers.get(msgType) || [];
    handlers.forEach((h) => h(data));
    const allHandlers = this.handlers.get('*') || [];
    allHandlers.forEach((h) => h(data));
  }

  on(msgType: string, handler: MessageHandler) {
    if (!this.handlers.has(msgType)) {
      this.handlers.set(msgType, []);
    }
    this.handlers.get(msgType)!.push(handler);
  }

  off(msgType: string, handler: MessageHandler) {
    const list = this.handlers.get(msgType);
    if (!list) return;
    this.handlers.set(
      msgType,
      list.filter((h) => h !== handler)
    );
  }

  send(data: Record<string, unknown>) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(data));
    }
  }

  subscribeTicks(symbol: string) {
    this.send({ ticks: symbol, subscribe: 1 });
  }

  forgetAll() {
    this.send({ forget_all: 'ticks' });
  }

  subscribeCandles(symbol: string, granularity = 60) {
    this.send({
      ticks_history: symbol,
      adjust_start_time: 1,
      count: 100,
      end: 'latest',
      granularity,
      style: 'candles',
      subscribe: 1,
    });
  }

  buy(contractType: string, symbol: string, amount: number) {
    this.send({
      buy: 1,
      subscribe: 1,
      price: amount,
      parameters: {
        contract_type: contractType,
        symbol,
        currency: 'USD',
        amount,
        basis: 'stake',
      },
    });
  }

  sell(contractId: number, price: number) {
    this.send({
      sell: contractId,
      price,
    });
  }

  getBalance() {
    this.send({ balance: 1, subscribe: 1 });
  }

  getHistory(symbol: string, count = 100, granularity = 60): Promise<Candle[]> {
    return new Promise((resolve) => {
      const handler = (data: Record<string, unknown>) => {
        if (data.msg_type === 'ticks_history' && data.candles) {
          this.off('ticks_history', handler);
          resolve(data.candles as Candle[]);
        }
      };
      this.on('ticks_history', handler);
      this.send({
        ticks_history: symbol,
        adjust_start_time: 1,
        count,
        end: 'latest',
        granularity,
        style: 'candles',
      });
      setTimeout(() => {
        this.off('ticks_history', handler);
        resolve([]);
      }, 10000);
    });
  }
}

export const derivApi = new DerivAPI();
