import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '../lib/supabase';
import type { BotStatus, BotSession, Environment } from '../lib/types';

export function useBotSession(userId: string | undefined, environment: Environment) {
  const [status, setStatus] = useState<BotStatus>('off');
  const [session, setSession] = useState<BotSession | null>(null);
  const [dailyPnl, setDailyPnl] = useState(0);
  const [dailyTrades, setDailyTrades] = useState(0);
  const [consecutiveLosses, setConsecutiveLosses] = useState(0);
  const [pausedUntil, setPausedUntil] = useState<string | null>(null);
  const [connected, setConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const pingIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const clearConnection = useCallback(() => {
    if (pingIntervalRef.current) clearInterval(pingIntervalRef.current);
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    setConnected(false);
  }, []);

  const startBot = useCallback(async () => {
    if (!userId) return;
    const { data } = await supabase
      .from('bot_sessions')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (data) {
      await supabase
        .from('bot_sessions')
        .update({ status: 'running', environment, connected_at: new Date().toISOString() })
        .eq('id', data.id);
      setSession({ ...data, status: 'running', environment });
    } else {
      const { data: newSession } = await supabase
        .from('bot_sessions')
        .insert({
          user_id: userId,
          status: 'running',
          environment,
          connected_at: new Date().toISOString(),
        })
        .select()
        .maybeSingle();
      setSession(newSession ?? null);
    }
    setStatus('running');
  }, [userId, environment]);

  const stopBot = useCallback(async () => {
    if (!userId || !session) return;
    await supabase
      .from('bot_sessions')
      .update({ status: 'off', disconnected_at: new Date().toISOString() })
      .eq('id', session.id);
    setStatus('off');
    clearConnection();
  }, [userId, session, clearConnection]);

  const panicStop = useCallback(async () => {
    if (!userId || !session) return;
    await supabase
      .from('bot_sessions')
      .update({ status: 'paused' })
      .eq('id', session.id);
    setStatus('paused');
    clearConnection();
  }, [userId, session, clearConnection]);

  const resumeFromPause = useCallback(async () => {
    if (!userId || !session) return;
    await supabase
      .from('bot_sessions')
      .update({ status: 'running', paused_until: null })
      .eq('id', session.id);
    setStatus('running');
  }, [userId, session]);

  useEffect(() => {
    if (!userId) return;
    const interval = setInterval(async () => {
      const { data } = await supabase
        .from('bot_sessions')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      if (data) {
        setSession(data);
        setDailyPnl(data.daily_pnl);
        setDailyTrades(data.daily_trades);
        setConsecutiveLosses(data.consecutive_losses);
        setPausedUntil(data.paused_until);
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [userId]);

  return {
    status,
    session,
    dailyPnl,
    dailyTrades,
    consecutiveLosses,
    pausedUntil,
    connected,
    startBot,
    stopBot,
    panicStop,
    resumeFromPause,
    setDailyPnl,
    setDailyTrades,
    setConsecutiveLosses,
  };
}
